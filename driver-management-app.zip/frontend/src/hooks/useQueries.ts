import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import { toast } from 'sonner';
import type { UserProfile, Driver, DriverStatus, DriverCategory, RouteTiming, RouteId, UserWithRole } from '../backend';
import { Principal } from '@dfinity/principal';

// ── User Profile ─────────────────────────────────────────────────────────────

export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveCallerUserProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
      toast.success('Profile saved successfully');
    },
    onError: () => {
      toast.error('Failed to save profile');
    },
  });
}

// ── Admin Check ───────────────────────────────────────────────────────────────

export function useIsCallerAdmin() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['isCallerAdmin'],
    queryFn: async () => {
      if (!actor) return false;
      return actor.isCallerAdmin();
    },
    enabled: !!actor && !actorFetching,
  });
}

// ── User Management ───────────────────────────────────────────────────────────

export function useGetUsers() {
  const { actor, isFetching } = useActor();

  return useQuery<UserWithRole[]>({
    queryKey: ['users'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getUsers();
    },
    enabled: !!actor && !isFetching,
  });
}

export function usePromoteToAdmin() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (userId: Principal) => {
      if (!actor) throw new Error('Actor not available');
      return actor.promoteToAdmin(userId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      toast.success('User promoted to Admin');
    },
    onError: (error: any) => {
      toast.error(error?.message?.includes('Unauthorized') ? 'Only admins can promote users' : 'Failed to promote user');
    },
  });
}

export function useDemoteFromAdmin() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (userId: Principal) => {
      if (!actor) throw new Error('Actor not available');
      return actor.demoteFromAdmin(userId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      toast.success('Admin demoted to User');
    },
    onError: (error: any) => {
      toast.error(error?.message?.includes('Unauthorized') ? 'Only admins can demote users' : 'Failed to demote user');
    },
  });
}

export function useBootstrapAdminSelf() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.bootstrapAdminSelf();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['isCallerAdmin'] });
      queryClient.invalidateQueries({ queryKey: ['users'] });
      toast.success('You are now an Admin!');
    },
    onError: (error: any) => {
      const msg = error?.message ?? '';
      if (msg.includes('Admin already exists')) {
        toast.error('An admin already exists. Self-promotion is no longer available.');
      } else {
        toast.error('Failed to become admin. Please try again.');
      }
    },
  });
}

// ── Routes ───────────────────────────────────────────────────────────────────

export function useRoutes() {
  const { actor, isFetching } = useActor();

  return useQuery<[RouteId, string][]>({
    queryKey: ['routes'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getRoutes();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAddRoute() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, name }: { id: string; name: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addRoute(id, name);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['routes'] });
      toast.success('Route added successfully');
    },
    onError: (error: any) => {
      toast.error(error?.message?.includes('Unauthorized') ? 'Only admins can add routes' : 'Failed to add route');
    },
  });
}

// ── Dashboard Stats ───────────────────────────────────────────────────────────

export function useDashboardStats() {
  const { actor, isFetching } = useActor();

  return useQuery({
    queryKey: ['dashboardStats'],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getDashboardStats();
    },
    enabled: !!actor && !isFetching,
  });
}

// ── Drivers ───────────────────────────────────────────────────────────────────

export function useGetDrivers() {
  const { actor, isFetching } = useActor();

  return useQuery<Driver[]>({
    queryKey: ['drivers'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getDrivers();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSearchDrivers(query: string) {
  const { actor, isFetching } = useActor();

  return useQuery<Driver[]>({
    queryKey: ['drivers', 'search', query],
    queryFn: async () => {
      if (!actor || !query.trim()) return [];
      return actor.searchDriversByName(query);
    },
    enabled: !!actor && !isFetching && !!query.trim(),
  });
}

export function useFilterDriversByStatus(status: DriverStatus | null) {
  const { actor, isFetching } = useActor();

  return useQuery<Driver[]>({
    queryKey: ['drivers', 'filter', 'status', status],
    queryFn: async () => {
      if (!actor || !status) return [];
      return actor.filterDriversByStatus(status);
    },
    enabled: !!actor && !isFetching && !!status,
  });
}

export function useGetDriversSorted(field: string) {
  const { actor, isFetching } = useActor();

  return useQuery<Driver[]>({
    queryKey: ['drivers', 'sorted', field],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getDriversSorted(field);
    },
    enabled: !!actor && !isFetching,
  });
}

export function useCreateDriver() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      name,
      licenseNumber,
      category,
      routeIds,
      routeTimings,
    }: {
      name: string;
      licenseNumber: string;
      category: DriverCategory;
      routeIds: RouteId[];
      routeTimings: RouteTiming[];
    }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.createDriver(name, licenseNumber, category, routeIds, routeTimings);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['drivers'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardStats'] });
      toast.success('Driver created successfully');
    },
    onError: () => {
      toast.error('Failed to create driver');
    },
  });
}

export function useUpdateDriver() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      id,
      name,
      licenseNumber,
      status,
      category,
      routeIds,
      routeTimings,
    }: {
      id: bigint;
      name: string;
      licenseNumber: string;
      status: DriverStatus;
      category: DriverCategory;
      routeIds: RouteId[];
      routeTimings: RouteTiming[];
    }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.updateDriver(id, name, licenseNumber, status, category, routeIds, routeTimings);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['drivers'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardStats'] });
      toast.success('Driver updated successfully');
    },
    onError: () => {
      toast.error('Failed to update driver');
    },
  });
}

export function useDeleteDriver() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: bigint) => {
      if (!actor) throw new Error('Actor not available');
      return actor.deleteDriver(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['drivers'] });
      queryClient.invalidateQueries({ queryKey: ['dashboardStats'] });
      toast.success('Driver deleted successfully');
    },
    onError: () => {
      toast.error('Failed to delete driver');
    },
  });
}
