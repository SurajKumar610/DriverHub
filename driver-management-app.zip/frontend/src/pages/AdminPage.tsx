import React from 'react';
import { Shield, ShieldOff, ShieldCheck, ShieldPlus, Loader2, Users } from 'lucide-react';
import { useGetUsers, usePromoteToAdmin, useDemoteFromAdmin, useIsCallerAdmin, useBootstrapAdminSelf } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { UserRole } from '../backend';
import { Principal } from '@dfinity/principal';

export default function AdminPage() {
  const { identity } = useInternetIdentity();
  const { data: users, isLoading, isError } = useGetUsers();
  const { data: isAdmin } = useIsCallerAdmin();
  const promoteMutation = usePromoteToAdmin();
  const demoteMutation = useDemoteFromAdmin();
  const bootstrapMutation = useBootstrapAdminSelf();

  const currentPrincipal = identity?.getPrincipal().toString();

  const isCurrentUser = (principal: Principal) =>
    principal.toString() === currentPrincipal;

  const handlePromote = (principal: Principal) => {
    promoteMutation.mutate(principal);
  };

  const handleDemote = (principal: Principal) => {
    demoteMutation.mutate(principal);
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between gap-3 mb-1">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-primary" />
            </div>
            <h1 className="text-2xl font-bold font-display text-foreground">Admin Management</h1>
          </div>

          {/* Make Me Admin button — only shown when current user is NOT an admin */}
          {isAdmin === false && (
            <Button
              variant="outline"
              size="sm"
              disabled={bootstrapMutation.isPending}
              onClick={() => bootstrapMutation.mutate()}
              className="gap-2 text-primary border-primary/30 hover:bg-primary/10 hover:text-primary"
            >
              {bootstrapMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <ShieldPlus className="w-4 h-4" />
              )}
              Make Me Admin
            </Button>
          )}
        </div>
        <p className="text-muted-foreground text-sm ml-12">
          Manage user roles and admin access for your organization.
        </p>
      </div>

      {/* Stats bar */}
      {!isLoading && users && (
        <div className="flex items-center gap-6 mb-6 p-4 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Total Users:</span>
            <span className="text-sm font-semibold text-foreground">{users.length}</span>
          </div>
          <div className="w-px h-4 bg-border" />
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Admins:</span>
            <span className="text-sm font-semibold text-foreground">
              {users.filter((u) => u.role === UserRole.admin).length}
            </span>
          </div>
          <div className="w-px h-4 bg-border" />
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Regular Users:</span>
            <span className="text-sm font-semibold text-foreground">
              {users.filter((u) => u.role === UserRole.user).length}
            </span>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-transparent">
              <TableHead className="text-muted-foreground font-medium">Name</TableHead>
              <TableHead className="text-muted-foreground font-medium">Email</TableHead>
              <TableHead className="text-muted-foreground font-medium">Role</TableHead>
              <TableHead className="text-muted-foreground font-medium text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading && (
              <>
                {[1, 2, 3].map((i) => (
                  <TableRow key={i} className="border-border">
                    <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-48" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-16 rounded-full" /></TableCell>
                    <TableCell className="text-right"><Skeleton className="h-8 w-28 ml-auto" /></TableCell>
                  </TableRow>
                ))}
              </>
            )}

            {isError && (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-12 text-muted-foreground">
                  <div className="flex flex-col items-center gap-2">
                    <ShieldOff className="w-8 h-8 opacity-40" />
                    <p className="text-sm">Failed to load users. You may not have admin access.</p>
                  </div>
                </TableCell>
              </TableRow>
            )}

            {!isLoading && !isError && users && users.length === 0 && (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-12 text-muted-foreground">
                  <div className="flex flex-col items-center gap-2">
                    <Users className="w-8 h-8 opacity-40" />
                    <p className="text-sm">No users found.</p>
                  </div>
                </TableCell>
              </TableRow>
            )}

            {!isLoading && !isError && users && users.map((user) => {
              const isSelf = isCurrentUser(user.principal);
              const isUserAdmin = user.role === UserRole.admin;
              const isPromoting = promoteMutation.isPending && promoteMutation.variables?.toString() === user.principal.toString();
              const isDemoting = demoteMutation.isPending && demoteMutation.variables?.toString() === user.principal.toString();
              const isBusy = isPromoting || isDemoting;

              return (
                <TableRow key={user.principal.toString()} className="border-border">
                  <TableCell className="font-medium text-foreground">
                    <div className="flex items-center gap-2">
                      {user.name}
                      {isSelf && (
                        <span className="text-xs text-muted-foreground bg-muted px-1.5 py-0.5 rounded-md">You</span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">{user.email}</TableCell>
                  <TableCell>
                    {isUserAdmin ? (
                      <Badge className="gap-1 bg-primary/10 text-primary border-primary/20 hover:bg-primary/10">
                        <Shield className="w-3 h-3" />
                        Admin
                      </Badge>
                    ) : (
                      <Badge variant="secondary" className="gap-1">
                        <Users className="w-3 h-3" />
                        User
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    {isSelf ? (
                      <span className="text-xs text-muted-foreground italic">Cannot modify own role</span>
                    ) : isUserAdmin ? (
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={isBusy}
                        onClick={() => handleDemote(user.principal)}
                        className="gap-1.5 text-destructive border-destructive/30 hover:bg-destructive/10 hover:text-destructive"
                      >
                        {isDemoting ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <ShieldOff className="w-3.5 h-3.5" />
                        )}
                        Demote to User
                      </Button>
                    ) : (
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={isBusy}
                        onClick={() => handlePromote(user.principal)}
                        className="gap-1.5 text-primary border-primary/30 hover:bg-primary/10 hover:text-primary"
                      >
                        {isPromoting ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Shield className="w-3.5 h-3.5" />
                        )}
                        Promote to Admin
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      <p className="text-xs text-muted-foreground mt-4 text-center">
        Role changes take effect immediately. Admins can manage drivers, routes, and other users.
      </p>
    </div>
  );
}
