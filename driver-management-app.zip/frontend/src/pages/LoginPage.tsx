import React, { useState, useEffect } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Button } from '@/components/ui/button';
import { Loader2, Shield, Zap, Users } from 'lucide-react';

export default function LoginPage() {
  const { login, loginStatus, identity, isLoggingIn, isInitializing } = useInternetIdentity();
  const navigate = useNavigate();
  const [loginError, setLoginError] = useState<string | null>(null);

  useEffect(() => {
    if (identity) {
      navigate({ to: '/dashboard' });
    }
  }, [identity, navigate]);

  const handleLogin = async () => {
    setLoginError(null);
    try {
      await login();
    } catch (error: unknown) {
      const err = error as Error;
      if (err?.message === 'User is already authenticated') {
        navigate({ to: '/dashboard' });
      } else {
        setLoginError('Login failed. Please try again.');
      }
    }
  };

  const features = [
    { icon: Users, title: 'Driver Management', desc: 'Full CRUD for driver records' },
    { icon: Shield, title: 'Secure Access', desc: 'Internet Identity authentication' },
    { icon: Zap, title: 'Real-time Stats', desc: 'Live dashboard analytics' },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col lg:flex-row">
      {/* Left panel - branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-sidebar flex-col justify-between p-12 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-20 left-20 w-64 h-64 rounded-full bg-primary blur-3xl" />
          <div className="absolute bottom-20 right-20 w-48 h-48 rounded-full bg-primary blur-3xl" />
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-16">
            <img
              src="/assets/generated/driver-manager-icon.dim_128x128.png"
              alt="Driver Manager"
              className="w-12 h-12 rounded-xl object-cover"
            />
            <div>
              <h1 className="font-display font-bold text-sidebar-foreground text-xl">
                Driver Manager
              </h1>
              <p className="text-sidebar-foreground/50 text-sm">Fleet Control System</p>
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <h2 className="font-display font-bold text-sidebar-foreground text-3xl leading-tight mb-3">
                Manage your fleet{' '}
                <span className="text-primary">efficiently</span>
              </h2>
              <p className="text-sidebar-foreground/60 text-base leading-relaxed">
                A powerful driver management platform built on the Internet Computer. Track, manage,
                and analyze your driver fleet with ease.
              </p>
            </div>

            <div className="space-y-4">
              {features.map(({ icon: Icon, title, desc }) => (
                <div key={title} className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold text-sidebar-foreground text-sm">{title}</p>
                    <p className="text-sidebar-foreground/50 text-sm">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <p className="relative z-10 text-sidebar-foreground/30 text-xs">
          © {new Date().getFullYear()} Driver Manager. All rights reserved.
        </p>
      </div>

      {/* Right panel - login form */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="lg:hidden flex flex-col items-center mb-10">
            <img
              src="/assets/generated/driver-manager-banner.dim_600x120.png"
              alt="Driver Manager"
              className="w-full max-w-xs object-contain mb-2"
            />
          </div>

          {/* Desktop banner */}
          <div className="hidden lg:block mb-10">
            <img
              src="/assets/generated/driver-manager-banner.dim_600x120.png"
              alt="Driver Manager"
              className="w-full object-contain"
            />
          </div>

          <div className="bg-card border border-border rounded-2xl p-8 shadow-card">
            <div className="mb-8">
              <h2 className="font-display font-bold text-2xl text-foreground mb-2">
                Welcome back
              </h2>
              <p className="text-muted-foreground text-sm">
                Sign in with your Internet Identity to access the dashboard.
              </p>
            </div>

            {loginError && (
              <div className="mb-4 p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm">
                {loginError}
              </div>
            )}

            {loginStatus === 'loginError' && !loginError && (
              <div className="mb-4 p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm">
                Authentication failed. Please try again.
              </div>
            )}

            <Button
              onClick={handleLogin}
              disabled={isLoggingIn || isInitializing}
              className="w-full gradient-amber text-primary-foreground font-semibold h-11 text-base rounded-xl"
            >
              {isLoggingIn || isInitializing ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  {isInitializing ? 'Initializing...' : 'Signing in...'}
                </>
              ) : (
                <>
                  <Shield className="w-5 h-5 mr-2" />
                  Sign in with Internet Identity
                </>
              )}
            </Button>

            <p className="mt-6 text-center text-xs text-muted-foreground leading-relaxed">
              Internet Identity provides secure, passwordless authentication.
              <br />
              Your data is stored on the Internet Computer blockchain.
            </p>
          </div>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            Built with <span className="text-primary">♥</span> using{' '}
            <a
              href={`https://caffeine.ai/?utm_source=Caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname || 'driver-management-app')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline font-medium"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
