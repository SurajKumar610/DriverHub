import React from 'react';
import { useDashboardStats, useGetDrivers } from '../hooks/useQueries';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { Users, CheckCircle2, XCircle, TrendingUp } from 'lucide-react';
import { DriverStatus } from '../backend';

const chartConfig = {
  active: { label: 'Active', color: '#f59e0b' },
  inactive: { label: 'Inactive', color: '#57534e' },
};

export default function DashboardPage() {
  const { data: stats, isLoading: statsLoading } = useDashboardStats();
  const { data: drivers, isLoading: driversLoading } = useGetDrivers();

  const total = stats ? Number(stats.total) : 0;
  const active = stats ? Number(stats.active) : 0;
  const inactive = stats ? Number(stats.inactive) : 0;
  const activePercent = total > 0 ? Math.round((active / total) * 100) : 0;

  const barData = [
    { name: 'Active', value: active, fill: '#f59e0b' },
    { name: 'Inactive', value: inactive, fill: '#57534e' },
  ];

  const pieData = [
    { name: 'Active', value: active },
    { name: 'Inactive', value: inactive },
  ];

  const PIE_COLORS = ['#f59e0b', '#57534e'];

  const recentDrivers = drivers ? [...drivers].slice(-5).reverse() : [];

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold font-display text-foreground">Dashboard</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Overview of your driver fleet and activity.
        </p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {statsLoading ? (
          [...Array(3)].map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)
        ) : (
          <>
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardDescription>Total Drivers</CardDescription>
                  <Users className="w-4 h-4 text-muted-foreground" />
                </div>
                <CardTitle className="text-3xl font-bold">{total}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground">All registered drivers</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardDescription>Active</CardDescription>
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                </div>
                <CardTitle className="text-3xl font-bold text-emerald-600 dark:text-emerald-400">
                  {active}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground">{activePercent}% of total fleet</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardDescription>Inactive</CardDescription>
                  <XCircle className="w-4 h-4 text-muted-foreground" />
                </div>
                <CardTitle className="text-3xl font-bold">{inactive}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground">{100 - activePercent}% of total fleet</p>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              Driver Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            {statsLoading ? (
              <Skeleton className="h-48 w-full" />
            ) : (
              <ChartContainer config={chartConfig} className="h-48 w-full">
                <BarChart data={barData} margin={{ top: 4, right: 4, bottom: 4, left: -20 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                    {barData.map((entry, index) => (
                      <Cell key={index} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Fleet Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
            {statsLoading ? (
              <Skeleton className="h-48 w-48 rounded-full" />
            ) : total === 0 ? (
              <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
                No data yet
              </div>
            ) : (
              <ChartContainer config={chartConfig} className="h-48 w-full">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {pieData.map((_, index) => (
                      <Cell key={index} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <ChartTooltip content={<ChartTooltipContent />} />
                </PieChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Drivers */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Recent Drivers</CardTitle>
          <CardDescription>Last 5 drivers added to the system</CardDescription>
        </CardHeader>
        <CardContent>
          {driversLoading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : recentDrivers.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">
              No drivers yet. Add your first driver to get started.
            </p>
          ) : (
            <div className="space-y-2">
              {recentDrivers.map((driver) => (
                <div
                  key={String(driver.id)}
                  className="flex items-center justify-between py-2 border-b border-border last:border-0"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <span className="text-xs font-bold text-primary">
                        {driver.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{driver.name}</p>
                      <p className="text-xs text-muted-foreground font-mono">{driver.licenseNumber}</p>
                    </div>
                  </div>
                  <Badge
                    variant={driver.status === DriverStatus.active ? 'default' : 'secondary'}
                    className={
                      driver.status === DriverStatus.active
                        ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-0 text-xs'
                        : 'bg-muted text-muted-foreground border-0 text-xs'
                    }
                  >
                    {driver.status === DriverStatus.active ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Footer */}
      <footer className="text-center text-xs text-muted-foreground pt-2">
        © {new Date().getFullYear()} DriverHub. Built with{' '}
        <span className="text-primary">♥</span> using{' '}
        <a
          href={`https://caffeine.ai/?utm_source=Caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname || 'driver-management-app')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="text-primary hover:underline font-medium"
        >
          caffeine.ai
        </a>
      </footer>
    </div>
  );
}
