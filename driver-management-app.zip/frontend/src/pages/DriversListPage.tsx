import React, { useState, useMemo } from 'react';
import { Plus, ChevronDown, ChevronUp, Clock, Route, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import DriverFormModal from '../components/DriverFormModal';
import DeleteDriverDialog from '../components/DeleteDriverDialog';
import DriverFilters, { type StatusFilter, type SortField } from '../components/DriverFilters';
import {
  useGetDrivers,
  useSearchDrivers,
  useFilterDriversByStatus,
  useGetDriversSorted,
  useRoutes,
} from '../hooks/useQueries';
import type { Driver, DriverStatus } from '../backend';

function getCategoryLabel(cat: string) {
  switch (cat) {
    case 'auto': return 'Auto';
    case 'busdriver': return 'Bus Driver';
    case 'cab': return 'Cab';
    default: return cat;
  }
}

function getCategoryColor(cat: string) {
  switch (cat) {
    case 'auto': return 'bg-amber-500/15 text-amber-700 dark:text-amber-400';
    case 'busdriver': return 'bg-blue-500/15 text-blue-700 dark:text-blue-400';
    case 'cab': return 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400';
    default: return 'bg-muted text-muted-foreground';
  }
}

function DriverDetailPanel({
  driver,
  routeMap,
}: {
  driver: Driver;
  routeMap: Map<string, string>;
}) {
  const timingMap = new Map(driver.routeTimings.map((rt) => [rt.routeId, rt.timeSlots]));

  return (
    <div className="px-4 py-4 bg-muted/20 border-t border-border space-y-4">
      {/* Category */}
      <div className="flex items-center gap-2">
        <Tag className="w-4 h-4 text-muted-foreground" />
        <span className="text-sm text-muted-foreground">Category:</span>
        <span
          className={`text-xs font-medium px-2 py-0.5 rounded-full ${getCategoryColor(String(driver.category))}`}
        >
          {getCategoryLabel(String(driver.category))}
        </span>
      </div>

      {/* Routes & Timings */}
      {driver.routes.length === 0 ? (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Route className="w-4 h-4" />
          <span>No routes assigned</span>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Route className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm font-medium text-foreground">Assigned Routes & Timings</span>
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            {driver.routes.map((routeId) => {
              const routeName = routeMap.get(routeId) || routeId;
              const slots = timingMap.get(routeId) || [];
              return (
                <div
                  key={routeId}
                  className="border border-border rounded-lg p-3 bg-background space-y-2"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded bg-primary/10 flex items-center justify-center shrink-0">
                      <Route className="w-3.5 h-3.5 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{routeName}</p>
                      <p className="text-xs text-muted-foreground font-mono">{routeId}</p>
                    </div>
                  </div>
                  {slots.length === 0 ? (
                    <p className="text-xs text-muted-foreground pl-8">No time slots set</p>
                  ) : (
                    <div className="pl-8 space-y-1">
                      {slots.map((slot, idx) => {
                        const parts = slot.split(' ');
                        const timePart = parts[0] || '';
                        const label = parts.slice(1).join(' ');
                        const [start, end] = timePart.split('-');
                        return (
                          <div key={idx} className="flex items-center gap-2">
                            <Clock className="w-3 h-3 text-muted-foreground shrink-0" />
                            <span className="text-xs text-foreground font-mono">
                              {start} – {end}
                            </span>
                            {label && (
                              <Badge variant="secondary" className="text-xs h-4 px-1.5">
                                {label}
                              </Badge>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function DriverRow({
  driver,
  routeMap,
  onEdit,
  onDelete,
}: {
  driver: Driver;
  routeMap: Map<string, string>;
  onEdit: (driver: Driver) => void;
  onDelete: (driver: Driver) => void;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <>
      <TableRow className="cursor-pointer hover:bg-muted/30 transition-colors">
        <TableCell className="font-medium">{driver.name}</TableCell>
        <TableCell className="font-mono text-sm text-muted-foreground">
          {driver.licenseNumber}
        </TableCell>
        <TableCell>
          <Badge
            variant={String(driver.status) === 'active' ? 'default' : 'secondary'}
            className={
              String(driver.status) === 'active'
                ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-0'
                : 'bg-muted text-muted-foreground border-0'
            }
          >
            {String(driver.status) === 'active' ? 'Active' : 'Inactive'}
          </Badge>
        </TableCell>
        <TableCell>
          <span
            className={`text-xs font-medium px-2 py-0.5 rounded-full ${getCategoryColor(String(driver.category))}`}
          >
            {getCategoryLabel(String(driver.category))}
          </span>
        </TableCell>
        <TableCell>
          <div className="flex items-center gap-1 flex-wrap">
            {driver.routes.length === 0 ? (
              <span className="text-xs text-muted-foreground">—</span>
            ) : (
              driver.routes.slice(0, 2).map((routeId) => (
                <Badge key={routeId} variant="outline" className="text-xs">
                  {routeMap.get(routeId) || routeId}
                </Badge>
              ))
            )}
            {driver.routes.length > 2 && (
              <Badge variant="outline" className="text-xs">
                +{driver.routes.length - 2}
              </Badge>
            )}
          </div>
        </TableCell>
        <TableCell>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(driver)}
              className="h-7 px-2 text-xs"
            >
              Edit
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(driver)}
              className="h-7 px-2 text-xs text-destructive hover:text-destructive"
            >
              Delete
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={() => setExpanded((v) => !v)}
            >
              {expanded ? (
                <ChevronUp className="w-4 h-4" />
              ) : (
                <ChevronDown className="w-4 h-4" />
              )}
            </Button>
          </div>
        </TableCell>
      </TableRow>
      {expanded && (
        <TableRow>
          <TableCell colSpan={6} className="p-0">
            <DriverDetailPanel driver={driver} routeMap={routeMap} />
          </TableCell>
        </TableRow>
      )}
    </>
  );
}

export default function DriversListPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [sortField, setSortField] = useState<SortField>('none');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editDriver, setEditDriver] = useState<Driver | null>(null);
  const [deleteDriver, setDeleteDriver] = useState<Driver | null>(null);

  const { data: allDrivers, isLoading: allLoading } = useGetDrivers();
  const { data: searchResults } = useSearchDrivers(searchQuery);
  const { data: filteredByStatus } = useFilterDriversByStatus(
    statusFilter !== 'all' ? (statusFilter as DriverStatus) : null
  );
  const { data: sortedDrivers } = useGetDriversSorted(
    sortField !== 'none' ? sortField : 'id'
  );
  const { data: routes } = useRoutes();

  const routeMap = useMemo(() => new Map(routes || []), [routes]);

  const displayedDrivers = useMemo(() => {
    if (searchQuery.trim()) return searchResults || [];
    if (statusFilter !== 'all') return filteredByStatus || [];
    if (sortField !== 'none') return sortedDrivers || [];
    return allDrivers || [];
  }, [
    searchQuery,
    statusFilter,
    sortField,
    allDrivers,
    searchResults,
    filteredByStatus,
    sortedDrivers,
  ]);

  const isLoading = allLoading;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold font-display text-foreground">Drivers</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Manage your driver roster, routes, and schedules.
          </p>
        </div>
        <Button onClick={() => setShowAddModal(true)} className="gap-2">
          <Plus className="w-4 h-4" />
          Add Driver
        </Button>
      </div>

      {/* Filters */}
      <DriverFilters
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        statusFilter={statusFilter}
        onStatusFilterChange={setStatusFilter}
        sortField={sortField}
        onSortFieldChange={setSortField}
      />

      {/* Table */}
      {isLoading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-14 rounded-xl" />
          ))}
        </div>
      ) : displayedDrivers.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <p className="text-lg font-medium">No drivers found</p>
          <p className="text-sm mt-1">
            {searchQuery || statusFilter !== 'all'
              ? 'Try adjusting your filters.'
              : 'Add your first driver to get started.'}
          </p>
        </div>
      ) : (
        <div className="border border-border rounded-xl overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/40">
                <TableHead>Name</TableHead>
                <TableHead>License</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Routes</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {displayedDrivers.map((driver) => (
                <DriverRow
                  key={String(driver.id)}
                  driver={driver}
                  routeMap={routeMap}
                  onEdit={setEditDriver}
                  onDelete={setDeleteDriver}
                />
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Modals */}
      <DriverFormModal
        open={showAddModal || !!editDriver}
        onClose={() => {
          setShowAddModal(false);
          setEditDriver(null);
        }}
        driver={editDriver}
      />
      <DeleteDriverDialog
        open={!!deleteDriver}
        driver={deleteDriver}
        onClose={() => setDeleteDriver(null)}
      />
    </div>
  );
}
