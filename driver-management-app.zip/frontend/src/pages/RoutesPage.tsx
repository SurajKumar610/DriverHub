import React, { useState } from 'react';
import { Plus, Route, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { useRoutes, useAddRoute } from '../hooks/useQueries';
import { Skeleton } from '@/components/ui/skeleton';

function AddRouteModal({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const [routeId, setRouteId] = useState('');
  const [routeName, setRouteName] = useState('');
  const [errors, setErrors] = useState<{ id?: string; name?: string }>({});
  const addRoute = useAddRoute();

  const validate = () => {
    const errs: { id?: string; name?: string } = {};
    if (!routeId.trim()) errs.id = 'Route ID is required';
    else if (!/^[a-zA-Z0-9_-]+$/.test(routeId.trim()))
      errs.id = 'Only letters, numbers, hyphens, underscores allowed';
    if (!routeName.trim()) errs.name = 'Route name is required';
    return errs;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    await addRoute.mutateAsync({ id: routeId.trim(), name: routeName.trim() });
    setRouteId('');
    setRouteName('');
    setErrors({});
    onClose();
  };

  const handleClose = () => {
    setRouteId('');
    setRouteName('');
    setErrors({});
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Route className="w-5 h-5 text-primary" />
            Add New Route
          </DialogTitle>
          <DialogDescription>
            Create a new route that can be assigned to drivers.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          <div className="space-y-1.5">
            <Label htmlFor="routeId">Route ID</Label>
            <Input
              id="routeId"
              placeholder="e.g. route-01, R101"
              value={routeId}
              onChange={(e) => {
                setRouteId(e.target.value);
                if (errors.id) setErrors((prev) => ({ ...prev, id: undefined }));
              }}
              className={errors.id ? 'border-destructive' : ''}
            />
            {errors.id && <p className="text-xs text-destructive">{errors.id}</p>}
            <p className="text-xs text-muted-foreground">
              A unique identifier for this route (letters, numbers, hyphens, underscores).
            </p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="routeName">Route Name</Label>
            <Input
              id="routeName"
              placeholder="e.g. Downtown Express, Airport Shuttle"
              value={routeName}
              onChange={(e) => {
                setRouteName(e.target.value);
                if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
              }}
              className={errors.name ? 'border-destructive' : ''}
            />
            {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
          </div>
          <DialogFooter className="pt-2">
            <Button type="button" variant="outline" onClick={handleClose} disabled={addRoute.isPending}>
              Cancel
            </Button>
            <Button type="submit" disabled={addRoute.isPending}>
              {addRoute.isPending ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                  Adding…
                </span>
              ) : (
                'Add Route'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function RoutesPage() {
  const [showAddModal, setShowAddModal] = useState(false);
  const { data: routes, isLoading } = useRoutes();

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold font-display text-foreground flex items-center gap-2">
            <MapPin className="w-6 h-6 text-primary" />
            Routes
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Manage routes that can be assigned to drivers with custom time slots.
          </p>
        </div>
        <Button onClick={() => setShowAddModal(true)} className="gap-2">
          <Plus className="w-4 h-4" />
          Add Route
        </Button>
      </div>

      {/* Routes List */}
      {isLoading ? (
        <div className="grid gap-3 sm:grid-cols-2">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-20 rounded-xl" />
          ))}
        </div>
      ) : !routes || routes.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center gap-3">
            <div className="w-14 h-14 rounded-full bg-muted flex items-center justify-center">
              <Route className="w-7 h-7 text-muted-foreground" />
            </div>
            <div>
              <p className="font-semibold text-foreground">No routes yet</p>
              <p className="text-sm text-muted-foreground mt-1">
                Add routes here so they can be assigned to drivers with time slots.
              </p>
            </div>
            <Button onClick={() => setShowAddModal(true)} variant="outline" className="mt-2 gap-2">
              <Plus className="w-4 h-4" />
              Add your first route
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {routes.map(([id, name]) => (
            <Card key={id} className="hover:shadow-card transition-shadow">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Route className="w-4 h-4 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <CardTitle className="text-base truncate">{name}</CardTitle>
                      <CardDescription className="text-xs font-mono">{id}</CardDescription>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-xs text-muted-foreground">
                  Route ID: <span className="font-mono text-foreground">{id}</span>
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <AddRouteModal open={showAddModal} onClose={() => setShowAddModal(false)} />
    </div>
  );
}
