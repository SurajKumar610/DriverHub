import React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { createRouter, createRoute, createRootRoute, RouterProvider, Outlet } from '@tanstack/react-router';
import { ThemeProvider } from 'next-themes';
import { Toaster } from '@/components/ui/sonner';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import DriversListPage from './pages/DriversListPage';
import RoutesPage from './pages/RoutesPage';
import AdminPage from './pages/AdminPage';
import ProfileSetupModal from './components/ProfileSetupModal';
import { useInternetIdentity } from './hooks/useInternetIdentity';
import { useGetCallerUserProfile, useIsCallerAdmin } from './hooks/useQueries';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5,
      retry: 1,
    },
  },
});

// Root layout component
function RootLayout() {
  return <Outlet />;
}

// Auth guard wrapper
function AuthenticatedLayout() {
  const { identity, isInitializing } = useInternetIdentity();
  const {
    data: userProfile,
    isLoading: profileLoading,
    isFetched,
  } = useGetCallerUserProfile();

  const isAuthenticated = !!identity;
  const showProfileSetup = isAuthenticated && !profileLoading && isFetched && userProfile === null;

  if (isInitializing) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-muted-foreground">Loading…</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return (
    <>
      <Layout>
        <Outlet />
      </Layout>
      {showProfileSetup && <ProfileSetupModal open={showProfileSetup} />}
    </>
  );
}

// Admin guard wrapper
function AdminGuardLayout() {
  const { data: isAdmin, isLoading } = useIsCallerAdmin();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-muted-foreground">Checking permissions…</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4 text-center px-4">
          <div className="w-14 h-14 rounded-full bg-destructive/10 flex items-center justify-center">
            <span className="text-2xl">🔒</span>
          </div>
          <h2 className="text-xl font-bold text-foreground">Access Denied</h2>
          <p className="text-muted-foreground text-sm max-w-xs">
            You need Admin privileges to access this page.
          </p>
        </div>
      </div>
    );
  }

  return <Outlet />;
}

// Page components
function IndexPage() {
  return <DashboardPage />;
}

function DashboardRoutePage() {
  return <DashboardPage />;
}

function DriversRoutePage() {
  return <DriversListPage />;
}

function RoutesRoutePage() {
  return <RoutesPage />;
}

function AdminRoutePage() {
  return <AdminPage />;
}

// Router setup
const rootRoute = createRootRoute({ component: RootLayout });

const authRoute = createRoute({
  getParentRoute: () => rootRoute,
  id: 'auth',
  component: AuthenticatedLayout,
});

const indexRoute = createRoute({
  getParentRoute: () => authRoute,
  path: '/',
  component: IndexPage,
});

const dashboardRoute = createRoute({
  getParentRoute: () => authRoute,
  path: '/dashboard',
  component: DashboardRoutePage,
});

const driversRoute = createRoute({
  getParentRoute: () => authRoute,
  path: '/drivers',
  component: DriversRoutePage,
});

const routesRoute = createRoute({
  getParentRoute: () => authRoute,
  path: '/routes',
  component: RoutesRoutePage,
});

const adminGuardRoute = createRoute({
  getParentRoute: () => authRoute,
  id: 'adminGuard',
  component: AdminGuardLayout,
});

const adminRoute = createRoute({
  getParentRoute: () => adminGuardRoute,
  path: '/admin',
  component: AdminRoutePage,
});

const routeTree = rootRoute.addChildren([
  authRoute.addChildren([
    indexRoute,
    dashboardRoute,
    driversRoute,
    routesRoute,
    adminGuardRoute.addChildren([adminRoute]),
  ]),
]);

const router = createRouter({ routeTree });

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
        <RouterProvider router={router} />
        <Toaster richColors position="top-right" />
      </ThemeProvider>
    </QueryClientProvider>
  );
}
