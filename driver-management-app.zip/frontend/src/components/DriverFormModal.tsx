import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Clock, Route, ChevronDown, ChevronUp } from 'lucide-react';
import { useCreateDriver, useUpdateDriver, useRoutes } from '../hooks/useQueries';
import { validateDriverForm, type DriverFormErrors } from '../utils/driverValidation';
import type { Driver, DriverCategory, DriverStatus, RouteTiming } from '../backend';

interface TimeSlotRow {
  start: string;
  end: string;
  label: string;
}

interface RouteTimingState {
  [routeId: string]: TimeSlotRow[];
}

interface DriverFormModalProps {
  open: boolean;
  onClose: () => void;
  driver?: Driver | null;
}

const CATEGORY_OPTIONS: { value: DriverCategory; label: string }[] = [
  { value: 'auto' as DriverCategory, label: 'Auto' },
  { value: 'busdriver' as DriverCategory, label: 'Bus Driver' },
  { value: 'cab' as DriverCategory, label: 'Cab' },
];

const STATUS_OPTIONS: { value: DriverStatus; label: string }[] = [
  { value: 'active' as DriverStatus, label: 'Active' },
  { value: 'inactive' as DriverStatus, label: 'Inactive' },
];

function RouteTimingEditor({
  routeId,
  routeName,
  slots,
  onChange,
}: {
  routeId: string;
  routeName: string;
  slots: TimeSlotRow[];
  onChange: (slots: TimeSlotRow[]) => void;
}) {
  const [expanded, setExpanded] = useState(true);

  const addSlot = () => {
    onChange([...slots, { start: '', end: '', label: '' }]);
  };

  const removeSlot = (idx: number) => {
    onChange(slots.filter((_, i) => i !== idx));
  };

  const updateSlot = (idx: number, field: keyof TimeSlotRow, value: string) => {
    onChange(slots.map((s, i) => (i === idx ? { ...s, [field]: value } : s)));
  };

  return (
    <div className="border border-border rounded-lg overflow-hidden">
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className="w-full flex items-center justify-between px-3 py-2.5 bg-muted/40 hover:bg-muted/60 transition-colors"
      >
        <div className="flex items-center gap-2">
          <Route className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium text-foreground">{routeName}</span>
          <Badge variant="secondary" className="text-xs">
            {slots.length} slot{slots.length !== 1 ? 's' : ''}
          </Badge>
        </div>
        {expanded ? (
          <ChevronUp className="w-4 h-4 text-muted-foreground" />
        ) : (
          <ChevronDown className="w-4 h-4 text-muted-foreground" />
        )}
      </button>

      {expanded && (
        <div className="p-3 space-y-2">
          {slots.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-2">
              No time slots yet. Add one below.
            </p>
          ) : (
            <div className="space-y-2">
              {slots.map((slot, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <div className="flex items-center gap-1 flex-1">
                    <Clock className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                    <Input
                      type="time"
                      value={slot.start}
                      onChange={(e) => updateSlot(idx, 'start', e.target.value)}
                      className="h-8 text-xs"
                      placeholder="Start"
                    />
                    <span className="text-muted-foreground text-xs shrink-0">to</span>
                    <Input
                      type="time"
                      value={slot.end}
                      onChange={(e) => updateSlot(idx, 'end', e.target.value)}
                      className="h-8 text-xs"
                      placeholder="End"
                    />
                  </div>
                  <Input
                    value={slot.label}
                    onChange={(e) => updateSlot(idx, 'label', e.target.value)}
                    className="h-8 text-xs w-28"
                    placeholder="Label (opt.)"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 shrink-0 text-destructive hover:text-destructive"
                    onClick={() => removeSlot(idx)}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              ))}
            </div>
          )}
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="w-full h-7 text-xs gap-1"
            onClick={addSlot}
          >
            <Plus className="w-3 h-3" />
            Add Time Slot
          </Button>
        </div>
      )}
    </div>
  );
}

export default function DriverFormModal({ open, onClose, driver }: DriverFormModalProps) {
  const isEdit = !!driver;

  const [name, setName] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [status, setStatus] = useState<DriverStatus>('active' as DriverStatus);
  const [category, setCategory] = useState<DriverCategory>('auto' as DriverCategory);
  const [selectedRoutes, setSelectedRoutes] = useState<string[]>([]);
  const [routeTimings, setRouteTimings] = useState<RouteTimingState>({});
  // Use DriverFormErrors as the state type to match what validateDriverForm returns
  const [errors, setErrors] = useState<DriverFormErrors>({});

  const { data: routes, isLoading: routesLoading } = useRoutes();
  const createDriver = useCreateDriver();
  const updateDriver = useUpdateDriver();

  // Populate form when editing
  useEffect(() => {
    if (driver) {
      setName(driver.name);
      setLicenseNumber(driver.licenseNumber);
      setStatus(driver.status);
      setCategory(driver.category);
      setSelectedRoutes([...driver.routes]);

      // Build timing state from driver data
      const timingState: RouteTimingState = {};
      driver.routeTimings.forEach((rt) => {
        timingState[rt.routeId] = rt.timeSlots.map((slot) => {
          const parts = slot.split(' ');
          const timePart = parts[0] || '';
          const label = parts.slice(1).join(' ');
          const [start, end] = timePart.split('-');
          return { start: start || '', end: end || '', label };
        });
      });
      setRouteTimings(timingState);
    } else {
      setName('');
      setLicenseNumber('');
      setStatus('active' as DriverStatus);
      setCategory('auto' as DriverCategory);
      setSelectedRoutes([]);
      setRouteTimings({});
    }
    setErrors({});
  }, [driver, open]);

  const toggleRoute = (routeId: string) => {
    setSelectedRoutes((prev) => {
      if (prev.includes(routeId)) {
        const next = prev.filter((id) => id !== routeId);
        setRouteTimings((t) => {
          const copy = { ...t };
          delete copy[routeId];
          return copy;
        });
        return next;
      } else {
        setRouteTimings((t) => ({ ...t, [routeId]: [] }));
        return [...prev, routeId];
      }
    });
  };

  const updateRouteTimings = (routeId: string, slots: TimeSlotRow[]) => {
    setRouteTimings((prev) => ({ ...prev, [routeId]: slots }));
  };

  const buildRouteTimings = (): RouteTiming[] => {
    return selectedRoutes.map((routeId) => {
      const slots = routeTimings[routeId] || [];
      const timeSlots = slots
        .filter((s) => s.start || s.end)
        .map((s) => {
          const timePart = `${s.start}-${s.end}`;
          return s.label ? `${timePart} ${s.label}` : timePart;
        });
      return { routeId, timeSlots };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const validationErrors = validateDriverForm(name, licenseNumber, status, category);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    const builtTimings = buildRouteTimings();

    try {
      if (isEdit && driver) {
        await updateDriver.mutateAsync({
          id: driver.id,
          name,
          licenseNumber,
          status,
          category,
          routeIds: selectedRoutes,
          routeTimings: builtTimings,
        });
      } else {
        await createDriver.mutateAsync({
          name,
          licenseNumber,
          category,
          routeIds: selectedRoutes,
          routeTimings: builtTimings,
        });
      }
      onClose();
    } catch {
      // errors handled by mutation hooks
    }
  };

  const isPending = createDriver.isPending || updateDriver.isPending;

  const routeMap = new Map(routes || []);

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>{isEdit ? 'Edit Driver' : 'Add New Driver'}</DialogTitle>
          <DialogDescription>
            {isEdit
              ? 'Update driver information, routes, and time slots.'
              : 'Fill in driver details, assign routes, and set time slots.'}
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 overflow-y-auto pr-1">
          <form id="driver-form" onSubmit={handleSubmit} className="space-y-5 py-2 px-1">
            {/* Name */}
            <div className="space-y-1.5">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (errors.name) setErrors((p) => ({ ...p, name: undefined }));
                }}
                placeholder="Driver's full name"
                className={errors.name ? 'border-destructive' : ''}
              />
              {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
            </div>

            {/* License Number */}
            <div className="space-y-1.5">
              <Label htmlFor="license">License Number</Label>
              <Input
                id="license"
                value={licenseNumber}
                onChange={(e) => {
                  setLicenseNumber(e.target.value);
                  if (errors.licenseNumber) setErrors((p) => ({ ...p, licenseNumber: undefined }));
                }}
                placeholder="e.g. DL-1234567890"
                className={errors.licenseNumber ? 'border-destructive' : ''}
              />
              {errors.licenseNumber && (
                <p className="text-xs text-destructive">{errors.licenseNumber}</p>
              )}
            </div>

            {/* Status (edit only) */}
            {isEdit && (
              <div className="space-y-1.5">
                <Label>Status</Label>
                <RadioGroup
                  value={status}
                  onValueChange={(v) => setStatus(v as DriverStatus)}
                  className="flex gap-4"
                >
                  {STATUS_OPTIONS.map((opt) => (
                    <div key={opt.value} className="flex items-center gap-2">
                      <RadioGroupItem value={opt.value} id={`status-${opt.value}`} />
                      <Label htmlFor={`status-${opt.value}`} className="cursor-pointer font-normal">
                        {opt.label}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
            )}

            {/* Category */}
            <div className="space-y-1.5">
              <Label>Category</Label>
              <RadioGroup
                value={category}
                onValueChange={(v) => setCategory(v as DriverCategory)}
                className="flex gap-4"
              >
                {CATEGORY_OPTIONS.map((opt) => (
                  <div key={opt.value} className="flex items-center gap-2">
                    <RadioGroupItem value={opt.value} id={`cat-${opt.value}`} />
                    <Label htmlFor={`cat-${opt.value}`} className="cursor-pointer font-normal">
                      {opt.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
              {errors.category && <p className="text-xs text-destructive">{errors.category}</p>}
            </div>

            {/* Routes */}
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5">
                <Route className="w-4 h-4 text-primary" />
                Assign Routes
              </Label>

              {routesLoading ? (
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-8 bg-muted animate-pulse rounded-md" />
                  ))}
                </div>
              ) : !routes || routes.length === 0 ? (
                <div className="border border-dashed border-border rounded-lg p-4 text-center">
                  <Route className="w-6 h-6 text-muted-foreground mx-auto mb-1" />
                  <p className="text-sm text-muted-foreground">No routes available.</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Go to the Routes page to add routes first.
                  </p>
                </div>
              ) : (
                <div className="border border-border rounded-lg divide-y divide-border">
                  {routes.map(([routeId, routeName]) => (
                    <label
                      key={routeId}
                      className="flex items-center gap-3 px-3 py-2.5 cursor-pointer hover:bg-muted/30 transition-colors"
                    >
                      <Checkbox
                        checked={selectedRoutes.includes(routeId)}
                        onCheckedChange={() => toggleRoute(routeId)}
                      />
                      <div className="flex-1 min-w-0">
                        <span className="text-sm font-medium text-foreground">{routeName}</span>
                        <span className="text-xs text-muted-foreground font-mono ml-2">{routeId}</span>
                      </div>
                    </label>
                  ))}
                </div>
              )}
            </div>

            {/* Per-Route Timings */}
            {selectedRoutes.length > 0 && (
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-primary" />
                  Route Timings
                </Label>
                <p className="text-xs text-muted-foreground">
                  Set time slots for each assigned route.
                </p>
                <div className="space-y-2">
                  {selectedRoutes.map((routeId) => (
                    <RouteTimingEditor
                      key={routeId}
                      routeId={routeId}
                      routeName={routeMap.get(routeId) || routeId}
                      slots={routeTimings[routeId] || []}
                      onChange={(slots) => updateRouteTimings(routeId, slots)}
                    />
                  ))}
                </div>
              </div>
            )}
          </form>
        </ScrollArea>

        <DialogFooter className="pt-4 border-t border-border">
          <Button type="button" variant="outline" onClick={onClose} disabled={isPending}>
            Cancel
          </Button>
          <Button type="submit" form="driver-form" disabled={isPending}>
            {isPending ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                {isEdit ? 'Saving…' : 'Creating…'}
              </span>
            ) : isEdit ? (
              'Save Changes'
            ) : (
              'Create Driver'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
