import React from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useDeleteDriver } from '../hooks/useQueries';
import { type Driver } from '../backend';
import { Loader2, AlertTriangle } from 'lucide-react';

interface DeleteDriverDialogProps {
  open: boolean;
  onClose: () => void;
  driver: Driver | null;
}

export default function DeleteDriverDialog({ open, onClose, driver }: DeleteDriverDialogProps) {
  const deleteDriver = useDeleteDriver();

  const handleConfirm = async () => {
    if (!driver) return;
    try {
      await deleteDriver.mutateAsync(driver.id);
      onClose();
    } catch {
      // Error handled by mutation hook
    }
  };

  return (
    <AlertDialog open={open} onOpenChange={(o) => !o && !deleteDriver.isPending && onClose()}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-full bg-destructive/15 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5 text-destructive" />
            </div>
            <AlertDialogTitle className="font-display">Delete Driver</AlertDialogTitle>
          </div>
          <AlertDialogDescription className="text-sm leading-relaxed">
            Are you sure you want to delete{' '}
            <span className="font-semibold text-foreground">{driver?.name}</span>? This action
            cannot be undone and will permanently remove the driver record.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="gap-2">
          <AlertDialogCancel disabled={deleteDriver.isPending}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleConfirm}
            disabled={deleteDriver.isPending}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {deleteDriver.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Deleting...
              </>
            ) : (
              'Delete Driver'
            )}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
