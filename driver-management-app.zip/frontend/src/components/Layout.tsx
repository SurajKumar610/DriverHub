import React from 'react';
import { Link, useLocation } from '@tanstack/react-router';
import {
  LayoutDashboard,
  Users,
  MapPin,
  LogOut,
  Menu,
  X,
  Truck,
  ShieldCheck,
  ShieldPlus,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { cn } from '@/lib/utils';
import { useIsCallerAdmin, useBootstrapAdminSelf } from '../hooks/useQueries';

const BASE_NAV_ITEMS = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/drivers', label: 'Drivers', icon: Users },
  { path: '/routes', label: 'Routes', icon: MapPin },
];

const ADMIN_NAV_ITEM = { path: '/admin', label: 'Admin', icon: ShieldCheck };

function NavLink({
  path,
  label,
  icon: Icon,
  onClick,
}: {
  path: string;
  label: string;
  icon: React.ElementType;
  onClick?: () => void;
}) {
  const location = useLocation();
  const isActive = location.pathname === path;

  return (
    <Link
      to={path}
      onClick={onClick}
      className={cn(
        'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
        isActive
          ? 'bg-primary text-primary-foreground'
          : 'text-muted-foreground hover:text-foreground hover:bg-muted'
      )}
    >
      <Icon className="w-4 h-4 shrink-0" />
      {label}
    </Link>
  );
}

function MakeMeAdminButton({ onClick }: { onClick?: () => void }) {
  const bootstrapMutation = useBootstrapAdminSelf();
  const { data: isAdmin, isLoading: adminLoading } = useIsCallerAdmin();

  // Only show when we know the user is NOT an admin
  if (adminLoading || isAdmin) return null;

  const handleClick = () => {
    bootstrapMutation.mutate();
    onClick?.();
  };

  return (
    <Button
      variant="outline"
      size="sm"
      disabled={bootstrapMutation.isPending}
      onClick={handleClick}
      className="w-full justify-start gap-3 text-primary border-primary/30 hover:bg-primary/10 hover:text-primary"
    >
      {bootstrapMutation.isPending ? (
        <Loader2 className="w-4 h-4 animate-spin shrink-0" />
      ) : (
        <ShieldPlus className="w-4 h-4 shrink-0" />
      )}
      Make Me Admin
    </Button>
  );
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const { clear, identity } = useInternetIdentity();
  const queryClient = useQueryClient();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { data: isAdmin } = useIsCallerAdmin();

  const navItems = isAdmin
    ? [...BASE_NAV_ITEMS, ADMIN_NAV_ITEM]
    : BASE_NAV_ITEMS;

  const handleLogout = async () => {
    await clear();
    queryClient.clear();
  };

  const isAuthenticated = !!identity;

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-60 border-r border-border bg-card shrink-0">
        {/* Logo */}
        <div className="flex items-center gap-2.5 px-4 py-5 border-b border-border">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shrink-0">
            <Truck className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-bold font-display text-foreground">DriverHub</span>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-1">
          {navItems.map((item) => (
            <NavLink key={item.path} {...item} />
          ))}
        </nav>

        {/* Footer */}
        <div className="p-3 border-t border-border space-y-1">
          {/* Make Me Admin — visible to authenticated non-admin users */}
          {isAuthenticated && !isAdmin && (
            <MakeMeAdminButton />
          )}
          <Button
            variant="ghost"
            className="w-full justify-start gap-3 text-muted-foreground hover:text-foreground"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4 shrink-0" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Mobile Top Bar */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-50 bg-card border-b border-border flex items-center justify-between px-4 h-14">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
            <Truck className="w-3.5 h-3.5 text-primary-foreground" />
          </div>
          <span className="font-bold font-display text-foreground text-sm">DriverHub</span>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setMobileOpen((v) => !v)}
          className="h-8 w-8"
        >
          {mobileOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
        </Button>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-background/80 backdrop-blur-sm" onClick={() => setMobileOpen(false)}>
          <div
            className="absolute top-14 left-0 right-0 bg-card border-b border-border p-3 space-y-1"
            onClick={(e) => e.stopPropagation()}
          >
            {navItems.map((item) => (
              <NavLink key={item.path} {...item} onClick={() => setMobileOpen(false)} />
            ))}
            <div className="pt-2 border-t border-border mt-2 space-y-1">
              {/* Make Me Admin — visible to authenticated non-admin users */}
              {isAuthenticated && !isAdmin && (
                <MakeMeAdminButton onClick={() => setMobileOpen(false)} />
              )}
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 text-muted-foreground"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 shrink-0" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 min-w-0 md:overflow-y-auto">
        <div className="md:hidden h-14" />
        {children}
      </main>
    </div>
  );
}
