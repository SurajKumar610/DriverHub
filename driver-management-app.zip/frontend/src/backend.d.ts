import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export type Time = bigint;
export interface UserWithRole {
    principal: Principal;
    name: string;
    role: UserRole;
    email: string;
}
export type DriverId = bigint;
export interface Driver {
    id: DriverId;
    status: DriverStatus;
    name: string;
    createdAt: Time;
    licenseNumber: string;
    category: DriverCategory;
    routes: Array<RouteId>;
    routeTimings: Array<RouteTiming>;
}
export type RouteId = string;
export interface RouteTiming {
    timeSlots: Array<string>;
    routeId: RouteId;
}
export interface UserProfile {
    name: string;
    email: string;
}
export enum DriverCategory {
    cab = "cab",
    auto = "auto",
    busdriver = "busdriver"
}
export enum DriverStatus {
    active = "active",
    inactive = "inactive"
}
export enum UserRole {
    admin = "admin",
    user = "user",
    guest = "guest"
}
export interface backendInterface {
    addRoute(id: RouteId, name: string): Promise<void>;
    assignCallerUserRole(user: Principal, role: UserRole): Promise<void>;
    bootstrapAdminSelf(): Promise<void>;
    createDriver(name: string, licenseNumber: string, category: DriverCategory, routeIds: Array<RouteId>, routeTimings: Array<RouteTiming>): Promise<DriverId>;
    deleteDriver(id: DriverId): Promise<void>;
    demoteFromAdmin(userId: Principal): Promise<void>;
    filterDriversByCategory(category: DriverCategory): Promise<Array<Driver>>;
    filterDriversByStatus(status: DriverStatus): Promise<Array<Driver>>;
    getCallerUserProfile(): Promise<UserProfile | null>;
    getCallerUserRole(): Promise<UserRole>;
    getDashboardStats(): Promise<{
        categories: Array<[DriverCategory, bigint]>;
        total: bigint;
        active: bigint;
        inactive: bigint;
    }>;
    getDriver(id: DriverId): Promise<Driver | null>;
    getDrivers(): Promise<Array<Driver>>;
    getDriversSorted(field: string): Promise<Array<Driver>>;
    getRoute(id: RouteId): Promise<string | null>;
    getRoutes(): Promise<Array<[RouteId, string]>>;
    getUserProfile(user: Principal): Promise<UserProfile | null>;
    getUsers(): Promise<Array<UserWithRole>>;
    isCallerAdmin(): Promise<boolean>;
    promoteToAdmin(userId: Principal): Promise<void>;
    saveCallerUserProfile(profile: UserProfile): Promise<void>;
    searchDriversByName(name_query: string): Promise<Array<Driver>>;
    updateDriver(id: DriverId, name: string, licenseNumber: string, newStatus: DriverStatus, category: DriverCategory, routeIds: Array<RouteId>, newRouteTimings: Array<RouteTiming>): Promise<void>;
    updateDriverStatus(id: DriverId, newStatus: DriverStatus): Promise<void>;
}
