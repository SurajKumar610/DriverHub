export interface DriverFormErrors {
  name?: string;
  licenseNumber?: string;
  status?: string;
  category?: string;
}

export function validateName(name: string): string | undefined {
  if (!name || name.trim().length === 0) {
    return 'Name is required';
  }
  if (name.trim().length < 2) {
    return 'Name must be at least 2 characters';
  }
  if (name.trim().length > 100) {
    return 'Name must be less than 100 characters';
  }
  return undefined;
}

export function validateLicenseNumber(licenseNumber: string): string | undefined {
  if (!licenseNumber || licenseNumber.trim().length === 0) {
    return 'License number is required';
  }
  const licenseRegex = /^[A-Za-z0-9]{2,10}$/;
  if (!licenseRegex.test(licenseNumber.trim())) {
    return 'License number must be 2–10 alphanumeric characters (letters and numbers only)';
  }
  return undefined;
}

export function validateStatus(status: string): string | undefined {
  if (!status || status.trim().length === 0) {
    return 'Status is required';
  }
  if (status !== 'active' && status !== 'inactive') {
    return 'Status must be Active or Inactive';
  }
  return undefined;
}

export function validateCategory(category: string): string | undefined {
  if (!category || category.trim().length === 0) {
    return 'Category is required';
  }
  if (category !== 'auto' && category !== 'busdriver' && category !== 'cab') {
    return 'Category must be Auto, Bus Driver, or Cab';
  }
  return undefined;
}

export function validateDriverForm(
  name: string,
  licenseNumber: string,
  status: string,
  category: string
): DriverFormErrors {
  const errors: DriverFormErrors = {};
  const nameError = validateName(name);
  const licenseError = validateLicenseNumber(licenseNumber);
  const statusError = validateStatus(status);
  const categoryError = validateCategory(category);

  if (nameError) errors.name = nameError;
  if (licenseError) errors.licenseNumber = licenseError;
  if (statusError) errors.status = statusError;
  if (categoryError) errors.category = categoryError;

  return errors;
}
