# Specification

## Summary
**Goal:** Fix the admin bootstrap catch-22 by making the "Make Me Admin" button visible to all authenticated non-admin users directly in the sidebar, removing the requirement to visit the Admin Management page first.

**Planned changes:**
- In `Layout.tsx`, remove the admin-role guard from the "Make Me Admin" button so it is visible in the sidebar for any authenticated user who does not yet have the Admin role
- The "Make Me Admin" button in the sidebar calls `bootstrapAdminSelf()`, shows a success or error toast, invalidates the admin-check and user queries, and makes the Admin Management sidebar link appear immediately on success without a page reload
- Hide the "Make Me Admin" button in the sidebar once the user already has the Admin role
- In `AdminPage.tsx`, ensure the existing "Make Me Admin" button is also rendered when the current user does not yet have the Admin role, and hidden once they do

**User-visible outcome:** A non-admin user sees a "Make Me Admin" button directly in the sidebar without needing to navigate to the Admin Management page first. After clicking it, they are immediately granted admin, the Admin Management link appears in the sidebar, and they can manage the application without any catch-22 situation.
